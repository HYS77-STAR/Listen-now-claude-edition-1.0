import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' show FontFeature, ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';

void openNowPlaying(BuildContext context) {
  if (!playback.hasCurrent) return;
  Navigator.of(context).push(
    PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 520),
      reverseTransitionDuration: const Duration(milliseconds: 420),
      pageBuilder: (_, __, ___) => const NowPlayingScreen(),
      transitionsBuilder: (context, anim, secondary, child) {
        final curved = CurvedAnimation(
          parent: anim,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero)
              .animate(curved),
          child: child,
        );
      },
    ),
  );
}

// =================================================================== MINI

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Song?>(
      valueListenable: playback.currentSong,
      builder: (context, song, _) {
        return AnimatedSize(
          duration: const Duration(milliseconds: 380),
          curve: Curves.easeOutCubic,
          alignment: Alignment.bottomCenter,
          child: song == null
              ? const SizedBox(width: double.infinity)
              : Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: FadeSlideIn(
                    key: const ValueKey<String>('mini'),
                    dy: 30,
                    child: _MiniBody(song: song),
                  ),
                ),
        );
      },
    );
  }
}

class _MiniBody extends StatelessWidget {
  final Song song;
  const _MiniBody({required this.song});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => openNowPlaying(context),
      onVerticalDragEnd: (d) {
        if ((d.primaryVelocity ?? 0) < -250) openNowPlaying(context);
      },
      onHorizontalDragEnd: (d) {
        final v = d.primaryVelocity ?? 0;
        if (v < -300) {
          HapticFeedback.selectionClick();
          playback.next();
        } else if (v > 300) {
          HapticFeedback.selectionClick();
          playback.previous();
        }
      },
      child: GlassBox(
        radius: 26,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(9, 9, 6, 7),
              child: Row(
                children: [
                  Hero(
                    tag: 'now_art',
                    child: SongArt(songId: song.id, size: 46, radius: 13),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 280),
                      child: Column(
                        key: ValueKey<int>(song.id),
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            song.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -0.2,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            song.artist,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 13, color: p.subtext),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Tappable(
                    onTap: playback.togglePlay,
                    pressedScale: 0.82,
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: StreamBuilder<bool>(
                        stream: playback.player.playingStream,
                        initialData: playback.player.playing,
                        builder: (context, snap) {
                          final playing = snap.data ?? false;
                          return AnimatedSwitcher(
                            duration: const Duration(milliseconds: 220),
                            transitionBuilder: (c, a) =>
                                ScaleTransition(scale: a, child: FadeTransition(opacity: a, child: c)),
                            child: GradientIcon(
                              playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                              key: ValueKey<bool>(playing),
                              size: 36,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Tappable(
                    onTap: playback.next,
                    pressedScale: 0.82,
                    child: const Padding(
                      padding: EdgeInsets.all(8),
                      child: GradientIcon(Icons.skip_next_rounded, size: 32),
                    ),
                  ),
                ],
              ),
            ),
            _MiniProgress(song: song),
          ],
        ),
      ),
    );
  }
}

class _MiniProgress extends StatelessWidget {
  final Song song;
  const _MiniProgress({required this.song});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return StreamBuilder<Duration>(
      stream: playback.player.positionStream,
      builder: (context, snap) {
        final pos = snap.data ?? Duration.zero;
        final total = song.durationMs > 0 ? song.durationMs : 1;
        final f = (pos.inMilliseconds / total).clamp(0.0, 1.0).toDouble();
        return SizedBox(
          height: 3,
          width: double.infinity,
          child: Stack(
            children: [
              Positioned.fill(child: Container(color: p.divider)),
              Align(
                alignment: Alignment.centerLeft,
                child: FractionallySizedBox(
                  widthFactor: f,
                  child: Container(
                    height: 3,
                    decoration: const BoxDecoration(gradient: AppColors.primary),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ============================================================= NOW PLAYING

class NowPlayingScreen extends StatelessWidget {
  const NowPlayingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarContrastEnforced: false,
      ),
      child: Scaffold(
        backgroundColor: Colors.black,
        body: ValueListenableBuilder<Song?>(
          valueListenable: playback.currentSong,
          builder: (context, song, _) {
            if (song == null) return const SizedBox.shrink();
            return _PlayerBody(song: song);
          },
        ),
      ),
    );
  }
}

class _PlayerBody extends StatelessWidget {
  final Song song;
  const _PlayerBody({required this.song});

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final artSize = math.min(mq.size.width - 56, mq.size.height * 0.36);
    return GestureDetector(
      onVerticalDragEnd: (d) {
        if ((d.primaryVelocity ?? 0) > 700) Navigator.of(context).maybePop();
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          _Backdrop(songId: song.id),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 26),
              child: Column(
                children: [
                  const SizedBox(height: 6),
                  _TopBar(song: song),
                  const Spacer(flex: 2),
                  StreamBuilder<bool>(
                    stream: playback.player.playingStream,
                    initialData: playback.player.playing,
                    builder: (context, snap) {
                      final playing = snap.data ?? false;
                      return AnimatedScale(
                        scale: playing ? 1.0 : 0.85,
                        duration: const Duration(milliseconds: 600),
                        curve: Curves.easeOutBack,
                        child: Hero(
                          tag: 'now_art',
                          child: SongArt(
                            songId: song.id,
                            size: artSize,
                            radius: 28,
                            px: 720,
                            shadow: true,
                          ),
                        ),
                      );
                    },
                  ),
                  const Spacer(flex: 2),
                  _TitleBlock(song: song),
                  const SizedBox(height: 14),
                  _SeekSection(song: song),
                  const SizedBox(height: 10),
                  const _Controls(),
                  const Spacer(flex: 1),
                  const _BottomRow(),
                  const SizedBox(height: 14),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Backdrop extends StatefulWidget {
  final int songId;
  const _Backdrop({required this.songId});

  @override
  State<_Backdrop> createState() => _BackdropState();
}

class _BackdropState extends State<_Backdrop> {
  Uint8List? _bytes;
  int _shown = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant _Backdrop oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.songId != widget.songId) _load();
  }

  void _load() {
    final id = widget.songId;
    if (musicLib.hasArtEntry(id, 300)) {
      _bytes = musicLib.peekArt(id, 300);
      _shown = id;
      return;
    }
    musicLib.loadArt(id, 300).then((b) {
      if (!mounted || widget.songId != id) return;
      setState(() {
        _bytes = b;
        _shown = id;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final Widget bg = _bytes == null
        ? Container(
            key: const ValueKey<String>('grad'),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF2346D6), Color(0xFF071233)],
              ),
            ),
          )
        : SizedBox.expand(
            key: ValueKey<int>(_shown),
            child: ImageFiltered(
              imageFilter: ImageFilter.blur(sigmaX: 46, sigmaY: 46),
              child: Image.memory(
                _bytes!,
                fit: BoxFit.cover,
                gaplessPlayback: true,
              ),
            ),
          );
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 800),
          child: bg,
        ),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withAlpha(90),
                Colors.black.withAlpha(120),
                Colors.black.withAlpha(215),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _TopBar extends StatelessWidget {
  final Song song;
  const _TopBar({required this.song});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _GlassCircle(
          icon: Icons.keyboard_arrow_down_rounded,
          onTap: () => Navigator.of(context).maybePop(),
        ),
        Expanded(
          child: Column(
            children: [
              Text(
                'NOW PLAYING',
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.6,
                  color: Colors.white.withAlpha(165),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                song.album,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        _GlassCircle(
          icon: Icons.more_horiz_rounded,
          onTap: () => showSongMenu(context, song),
        ),
      ],
    );
  }
}

class _GlassCircle extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _GlassCircle({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tappable(
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withAlpha(36),
        ),
        child: Icon(icon, color: Colors.white, size: 26),
      ),
    );
  }
}

class _TitleBlock extends StatelessWidget {
  final Song song;
  const _TitleBlock({required this.song});

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 320),
      transitionBuilder: (c, a) => FadeTransition(
        opacity: a,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.18), end: Offset.zero).animate(a),
          child: c,
        ),
      ),
      child: SizedBox(
        key: ValueKey<int>(song.id),
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              song.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.6,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              song.artist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 17.5,
                fontWeight: FontWeight.w500,
                color: Colors.white.withAlpha(170),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------- seek bar

class _SeekSection extends StatefulWidget {
  final Song song;
  const _SeekSection({required this.song});

  @override
  State<_SeekSection> createState() => _SeekSectionState();
}

class _SeekSectionState extends State<_SeekSection> {
  double? _drag; // 0..1 while the user is dragging

  Duration get _total {
    final d = playback.player.duration;
    if (d != null && d.inMilliseconds > 0) return d;
    return widget.song.duration;
  }

  double _fraction(Offset local, double width) =>
      (local.dx / width).clamp(0.0, 1.0).toDouble();

  void _seekTo(double f) {
    final ms = (_total.inMilliseconds * f).round();
    playback.player.seek(Duration(milliseconds: ms));
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: playback.player.positionStream,
      builder: (context, snap) {
        final total = _total;
        final totalMs = math.max(1, total.inMilliseconds);
        var pos = snap.data ?? playback.player.position;
        if (pos > total) pos = total;
        final frac = _drag ?? (pos.inMilliseconds / totalMs).clamp(0.0, 1.0).toDouble();
        final shownPos = _drag != null
            ? Duration(milliseconds: (totalMs * _drag!).round())
            : pos;
        final dragging = _drag != null;
        return Column(
          children: [
            LayoutBuilder(
              builder: (context, c) {
                final w = c.maxWidth;
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTapUp: (d) => _seekTo(_fraction(d.localPosition, w)),
                  onHorizontalDragStart: (d) =>
                      setState(() => _drag = _fraction(d.localPosition, w)),
                  onHorizontalDragUpdate: (d) =>
                      setState(() => _drag = _fraction(d.localPosition, w)),
                  onHorizontalDragEnd: (_) {
                    final f = _drag;
                    setState(() => _drag = null);
                    if (f != null) _seekTo(f);
                  },
                  onHorizontalDragCancel: () => setState(() => _drag = null),
                  child: SizedBox(
                    height: 30,
                    child: Center(
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        curve: Curves.easeOutCubic,
                        height: dragging ? 12 : 6,
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(50),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: FractionallySizedBox(
                            widthFactor: frac,
                            heightFactor: 1,
                            child: Container(
                              decoration: const BoxDecoration(gradient: AppColors.primary),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(fmtClock(shownPos), style: _timeStyle),
                Text('-${fmtClock(total - shownPos)}', style: _timeStyle),
              ],
            ),
          ],
        );
      },
    );
  }

  static final TextStyle _timeStyle = TextStyle(
    fontSize: 12.5,
    fontWeight: FontWeight.w600,
    color: Colors.white.withAlpha(150),
    fontFeatures: const [FontFeature.tabularFigures()],
  );
}

// ------------------------------------------------------------------ controls

class _Controls extends StatelessWidget {
  const _Controls();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: playback,
      builder: (context, _) {
        final shuffle = playback.shuffleOn;
        final loop = playback.loopMode;
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _ToggleButton(
              icon: Icons.shuffle_rounded,
              active: shuffle,
              onTap: playback.toggleShuffle,
            ),
            Tappable(
              onTap: playback.previous,
              pressedScale: 0.82,
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.skip_previous_rounded, color: Colors.white, size: 48),
              ),
            ),
            _PlayPauseButton(),
            Tappable(
              onTap: playback.next,
              pressedScale: 0.82,
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.skip_next_rounded, color: Colors.white, size: 48),
              ),
            ),
            _ToggleButton(
              icon: loop == LoopMode.one ? Icons.repeat_one_rounded : Icons.repeat_rounded,
              active: loop != LoopMode.off,
              onTap: playback.cycleRepeat,
            ),
          ],
        );
      },
    );
  }
}

class _ToggleButton extends StatelessWidget {
  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  const _ToggleButton({required this.icon, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tappable(
      onTap: onTap,
      pressedScale: 0.8,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
              child: Icon(
                icon,
                key: ValueKey<IconData>(icon),
                size: 26,
                color: active ? AppColors.blue2 : Colors.white.withAlpha(150),
              ),
            ),
            const SizedBox(height: 4),
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: active ? 5 : 0,
              height: active ? 5 : 0,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.blue2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayPauseButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Tappable(
      onTap: playback.togglePlay,
      pressedScale: 0.88,
      child: StreamBuilder<bool>(
        stream: playback.player.playingStream,
        initialData: playback.player.playing,
        builder: (context, snap) {
          final playing = snap.data ?? false;
          return Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: AppColors.primary,
              boxShadow: [
                BoxShadow(
                  color: alpha(AppColors.blue2, 0.45),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              transitionBuilder: (c, a) => ScaleTransition(
                scale: a,
                child: RotationTransition(
                  turns: Tween<double>(begin: 0.85, end: 1.0).animate(a),
                  child: c,
                ),
              ),
              child: Icon(
                playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                key: ValueKey<bool>(playing),
                color: Colors.white,
                size: 46,
              ),
            ),
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------- bottom row

class _BottomRow extends StatelessWidget {
  const _BottomRow();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ListenableBuilder(
          listenable: Listenable.merge(
              <Listenable>[playback.sleepRemaining, playback.sleepAtSongEnd]),
          builder: (context, _) {
            final rem = playback.sleepRemaining.value;
            final atEnd = playback.sleepAtSongEnd.value;
            final active = rem != null || atEnd;
            final label = rem != null ? fmtClock(rem) : (atEnd ? 'End of song' : 'Sleep');
            return _BottomButton(
              icon: Icons.bedtime_rounded,
              label: label,
              active: active,
              onTap: () => showSleepTimerSheet(context),
            );
          },
        ),
        _BottomButton(
          icon: Icons.queue_music_rounded,
          label: 'Queue',
          onTap: () => showQueueSheet(context),
        ),
        _BottomButton(
          icon: Icons.library_add_rounded,
          label: 'Playlist',
          onTap: () {
            final s = playback.currentSong.value;
            if (s != null) showAddToPlaylistSheet(context, <int>[s.id]);
          },
        ),
      ],
    );
  }
}

class _BottomButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _BottomButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = active ? AppColors.blue2 : Colors.white.withAlpha(190);
    return Tappable(
      onTap: onTap,
      pressedScale: 0.88,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(active ? 40 : 24),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 21, color: color),
            const SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w700,
                color: color,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================== SLEEP TIMER

void showSleepTimerSheet(BuildContext context) {
  showAppSheet<void>(
    context,
    builder: (ctx) => const SheetShell(child: _SleepSheet()),
  );
}

class _SleepSheet extends StatelessWidget {
  const _SleepSheet();

  static const List<int> _minutes = <int>[5, 10, 15, 30, 45, 60, 90];

  void _start(BuildContext context, Duration d) {
    Navigator.of(context).pop();
    playback.startSleepTimer(d);
    showToast('Music will stop in ${_describe(d)}');
  }

  static String _describe(Duration d) {
    final m = d.inMinutes;
    if (m < 60) return '$m min';
    final h = m ~/ 60;
    final rm = m % 60;
    return rm == 0 ? '$h hr' : '$h hr $rm min';
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ListenableBuilder(
      listenable: Listenable.merge(
          <Listenable>[playback.sleepRemaining, playback.sleepAtSongEnd]),
      builder: (context, _) {
        final rem = playback.sleepRemaining.value;
        final atEnd = playback.sleepAtSongEnd.value;
        final active = rem != null || atEnd;
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 6, 22, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Sleep Timer',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.5),
              ),
              const SizedBox(height: 4),
              Text(
                'Music fades out and pauses automatically.',
                style: TextStyle(fontSize: 14.5, color: p.subtext),
              ),
              const SizedBox(height: 16),
              AnimatedSize(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOutCubic,
                child: active
                    ? Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 16),
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        decoration: BoxDecoration(
                          gradient: AppColors.primary,
                          borderRadius: BorderRadius.circular(22),
                        ),
                        child: Column(
                          children: [
                            Text(
                              rem != null ? fmtClock(rem) : 'End of song',
                              style: TextStyle(
                                fontSize: rem != null ? 40 : 28,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                                fontFeatures: const [FontFeature.tabularFigures()],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              rem != null ? 'until playback stops' : 'playback will stop after this song',
                              style: TextStyle(color: Colors.white.withAlpha(215), fontSize: 14),
                            ),
                            const SizedBox(height: 14),
                            Tappable(
                              onTap: () {
                                playback.cancelSleep();
                                Navigator.of(context).pop();
                                showToast('Sleep timer cancelled');
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white.withAlpha(45),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: const Text(
                                  'Cancel Timer',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    : const SizedBox(width: double.infinity),
              ),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  for (final m in _minutes)
                    _chip(context, '$m min', () => _start(context, Duration(minutes: m))),
                  _chip(context, 'End of Song', () {
                    Navigator.of(context).pop();
                    playback.startSleepAtSongEnd();
                    showToast('Music will stop after this song');
                  }, highlight: true),
                  _chip(context, 'Custom…', () async {
                    Navigator.of(context).pop();
                    final d = await showAppDialog<Duration>(
                      context,
                      (ctx) => const _CustomTimerDialog(),
                    );
                    if (d != null) {
                      playback.startSleepTimer(d);
                      showToast('Music will stop in ${_describe(d)}');
                    }
                  }),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _chip(BuildContext context, String label, VoidCallback onTap,
      {bool highlight = false}) {
    final p = context.pal;
    return Tappable(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        decoration: BoxDecoration(
          gradient: highlight ? AppColors.soft : null,
          color: highlight ? null : p.surface2,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 15.5,
            fontWeight: FontWeight.w700,
            color: p.text,
          ),
        ),
      ),
    );
  }
}

class _CustomTimerDialog extends StatefulWidget {
  const _CustomTimerDialog();

  @override
  State<_CustomTimerDialog> createState() => _CustomTimerDialogState();
}

class _CustomTimerDialogState extends State<_CustomTimerDialog> {
  double _minutes = 20;

  String get _label {
    final m = _minutes.round();
    if (m < 60) return '$m min';
    final h = m ~/ 60;
    final rm = m % 60;
    return rm == 0 ? '$h hr' : '$h hr $rm min';
  }

  @override
  Widget build(BuildContext context) {
    return DialogCard(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Custom Timer',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 18),
          GradientText(
            _label,
            style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Slider(
            value: _minutes,
            min: 1,
            max: 180,
            divisions: 179,
            activeColor: AppColors.blue1,
            inactiveColor: alpha(AppColors.blue1, 0.22),
            onChanged: (v) => setState(() => _minutes = v),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: DialogButton(
                  label: 'Cancel',
                  onTap: () => Navigator.of(context).pop(),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DialogButton(
                  label: 'Start',
                  primary: true,
                  onTap: () => Navigator.of(context)
                      .pop(Duration(minutes: _minutes.round())),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ==================================================================== QUEUE

void showQueueSheet(BuildContext context) {
  showAppSheet<void>(
    context,
    builder: (ctx) => const SheetShell(tall: true, child: _QueueSheet()),
  );
}

class _QueueSheet extends StatefulWidget {
  const _QueueSheet();

  @override
  State<_QueueSheet> createState() => _QueueSheetState();
}

class _QueueSheetState extends State<_QueueSheet> {
  late final ScrollController _ctrl;

  @override
  void initState() {
    super.initState();
    final idx = playback.player.currentIndex ?? 0;
    _ctrl = ScrollController(
      initialScrollOffset: math.max(0, idx - 1) * 64.0,
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ListenableBuilder(
      listenable: playback,
      builder: (context, _) {
        final queue = playback.queue;
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 4, 22, 10),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Queue',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.5),
                    ),
                  ),
                  Text(
                    plural(queue.length, 'song'),
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: p.subtext),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ValueListenableBuilder<Song?>(
                valueListenable: playback.currentSong,
                builder: (context, cur, _) {
                  return ListView.builder(
                    controller: _ctrl,
                    itemCount: queue.length,
                    itemExtent: 64,
                    padding: const EdgeInsets.only(bottom: 16),
                    itemBuilder: (context, i) {
                      final s = queue[i];
                      final isCur = playback.player.currentIndex == i;
                      return Tappable(
                        onTap: () => playback.jumpTo(i),
                        pressedScale: 0.98,
                        child: Container(
                          height: 64,
                          color: Colors.transparent,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            children: [
                              SongArt(songId: s.id, size: 46, radius: 12),
                              const SizedBox(width: 13),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      s.title,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 15.5,
                                        fontWeight: FontWeight.w600,
                                        color: isCur ? AppColors.accent : p.text,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      s.artist,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(fontSize: 13, color: p.subtext),
                                    ),
                                  ],
                                ),
                              ),
                              if (isCur)
                                StreamBuilder<bool>(
                                  stream: playback.player.playingStream,
                                  initialData: playback.player.playing,
                                  builder: (context, snap) => EqualizerBars(
                                    active: snap.data ?? false,
                                    color: AppColors.accent,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
