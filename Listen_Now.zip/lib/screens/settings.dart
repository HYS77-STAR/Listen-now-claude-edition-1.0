import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../globals.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'details.dart';
import 'player.dart';
import 'tabs.dart';

// ================================================================ SETTINGS

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
          builder: (context, _) {
            final hiddenCount = appStore.hiddenFolders.length;
            return ListView(
              padding: const EdgeInsets.only(bottom: 60),
              children: [
                const DetailHeader(title: 'Settings', subtitle: 'Make it yours'),
                const SizedBox(height: 10),
                _section(context, 'APPEARANCE', [const _ThemeSelector()], padded: true),
                _section(context, 'LIBRARY', [
                  _SettingsRow(
                    icon: Icons.visibility_rounded,
                    label: 'Restore Hidden Files',
                    trailing: hiddenCount > 0 ? _Badge('$hiddenCount') : null,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const HiddenFilesScreen()),
                    ),
                  ),
                  _SettingsRow(
                    icon: Icons.refresh_rounded,
                    label: 'Rescan Library',
                    trailing: musicLib.loading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.4,
                              color: AppColors.accent,
                            ),
                          )
                        : Text(
                            plural(musicLib.all.length, 'song'),
                            style: TextStyle(fontSize: 14.5, color: p.subtext),
                          ),
                    onTap: () {
                      musicLib.scan();
                      showToast('Scanning your library…');
                    },
                  ),
                ]),
                _section(context, 'INSIGHTS', [
                  _SettingsRow(
                    icon: Icons.bar_chart_rounded,
                    label: 'Statistics',
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const StatsScreen()),
                    ),
                  ),
                ]),
                _section(context, 'PLAYBACK', [
                  _SettingsRow(
                    icon: Icons.bedtime_rounded,
                    label: 'Sleep Timer',
                    trailing: ListenableBuilder(
                      listenable: Listenable.merge(
                          <Listenable>[playback.sleepRemaining, playback.sleepAtSongEnd]),
                      builder: (context, _) {
                        final rem = playback.sleepRemaining.value;
                        final text = rem != null
                            ? fmtClock(rem)
                            : (playback.sleepAtSongEnd.value ? 'End of song' : 'Off');
                        return Text(text,
                            style: TextStyle(fontSize: 14.5, color: p.subtext));
                      },
                    ),
                    onTap: () => showSleepTimerSheet(context),
                  ),
                ]),
                _section(context, 'ABOUT', [
                  _SettingsRow(
                    icon: Icons.info_rounded,
                    label: 'Listen now',
                    trailing: Text('Version 1.0.0',
                        style: TextStyle(fontSize: 14.5, color: p.subtext)),
                    onTap: null,
                  ),
                ]),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _section(BuildContext context, String title, List<Widget> children,
      {bool padded = false}) {
    final p = context.pal;
    final rows = <Widget>[];
    for (var i = 0; i < children.length; i++) {
      rows.add(children[i]);
      if (!padded && i < children.length - 1) {
        rows.add(Padding(
          padding: const EdgeInsets.only(left: 62),
          child: Container(height: 1, color: p.divider),
        ));
      }
    }
    return FadeSlideIn(
      dy: 14,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 8, bottom: 8),
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                  color: p.subtext,
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                color: padded ? Colors.transparent : p.surface,
                borderRadius: BorderRadius.circular(22),
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(children: rows),
            ),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  const _Badge(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        gradient: AppColors.primary,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w800,
          fontSize: 13.5,
        ),
      ),
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsRow({
    required this.icon,
    required this.label,
    this.trailing,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Tappable(
      onTap: onTap,
      pressedScale: 0.98,
      child: Container(
        height: 58,
        color: Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                gradient: AppColors.primary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w600,
                  letterSpacing: -0.2,
                ),
              ),
            ),
            if (trailing != null) trailing!,
            if (onTap != null) ...[
              const SizedBox(width: 6),
              Icon(Icons.chevron_right_rounded, color: p.subtext, size: 24),
            ],
          ],
        ),
      ),
    );
  }
}

class _ThemeSelector extends StatelessWidget {
  const _ThemeSelector();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _ThemeCard(
            label: 'Light',
            icon: Icons.light_mode_rounded,
            selected: !appStore.isDark,
            previewBg: const Color(0xFFFFFFFF),
            previewBar: const Color(0xFFE6E6ED),
            onTap: () => appStore.setDark(false),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ThemeCard(
            label: 'Dark',
            icon: Icons.dark_mode_rounded,
            selected: appStore.isDark,
            previewBg: const Color(0xFF000000),
            previewBar: const Color(0xFF26262B),
            onTap: () => appStore.setDark(true),
          ),
        ),
      ],
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final Color previewBg;
  final Color previewBar;
  final VoidCallback onTap;

  const _ThemeCard({
    required this.label,
    required this.icon,
    required this.selected,
    required this.previewBg,
    required this.previewBar,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Tappable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: selected ? AppColors.blue2 : Colors.transparent,
            width: 2.2,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: alpha(AppColors.blue1, 0.28),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ]
              : null,
        ),
        child: Column(
          children: [
            Container(
              height: 86,
              decoration: BoxDecoration(
                color: previewBg,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: alpha(Colors.grey, 0.35)),
              ),
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 38,
                    height: 8,
                    decoration: BoxDecoration(
                      gradient: AppColors.primary,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(height: 8),
                  for (var i = 0; i < 3; i++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5),
                      child: Container(
                        height: 7,
                        decoration: BoxDecoration(
                          color: previewBar,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                selected ? GradientIcon(icon, size: 20) : Icon(icon, size: 20, color: p.subtext),
                const SizedBox(width: 7),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w700,
                    color: selected ? p.text : p.subtext,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ========================================================== RESTORE HIDDEN

class HiddenFilesScreen extends StatelessWidget {
  const HiddenFilesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: Listenable.merge(<Listenable>[appStore, musicLib]),
          builder: (context, _) {
            final hidden = musicLib.hiddenFolderInfos;
            return Column(
              children: [
                DetailHeader(
                  title: 'Restore Hidden Files',
                  subtitle: hidden.isEmpty
                      ? 'Nothing is hidden'
                      : '${plural(hidden.length, 'hidden folder')} · files stay safe on your device',
                  trailing: hidden.length > 1
                      ? GradientButton(
                          label: 'Restore All',
                          compact: true,
                          onTap: () {
                            appStore.restoreAll();
                            showToast('All folders restored');
                          },
                        )
                      : null,
                ),
                Expanded(
                  child: hidden.isEmpty
                      ? const EmptyState(
                          icon: Icons.visibility_rounded,
                          title: 'No Hidden Folders',
                          subtitle:
                              'Folders you hide from the Folders tab will appear here so you can bring them back anytime.',
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 8, bottom: 40),
                          itemCount: hidden.length,
                          itemBuilder: (context, i) {
                            final f = hidden[i];
                            return FadeSlideIn(
                              delay: Duration(milliseconds: 40 * math.min(i, 8)),
                              dy: 16,
                              child: Container(
                                height: 76,
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                child: Row(
                                  children: [
                                    Opacity(opacity: 0.85, child: const FolderIconBox()),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            f.name,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontSize: 16.5,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          const SizedBox(height: 3),
                                          Text(
                                            plural(f.songs.length, 'song'),
                                            style: TextStyle(fontSize: 13.5, color: p.subtext),
                                          ),
                                        ],
                                      ),
                                    ),
                                    GradientButton(
                                      label: 'Restore',
                                      compact: true,
                                      onTap: () {
                                        appStore.restoreFolder(f.path);
                                        showToast('"${f.name}" restored');
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ============================================================== STATISTICS

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  static const List<String> _dayNames = <String>['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  static const List<String> _monthLetters = <String>[
    'J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'
  ];

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: stats,
          builder: (context, _) {
            final today = stats.todayMs;
            final week = stats.lastDaysMs(7);
            final days = stats.lastDays(7);
            final months = stats.monthlyMs;
            final top = stats.topSongs(5);
            final nowMonth = DateTime.now().month - 1;
            return ListView(
              padding: const EdgeInsets.only(bottom: 60),
              children: [
                const DetailHeader(title: 'Statistics', subtitle: 'Your listening, in numbers'),
                const SizedBox(height: 8),
                // --- today hero
                FadeSlideIn(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        gradient: AppColors.primary,
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: [
                          BoxShadow(
                            color: alpha(AppColors.blue1, 0.35),
                            blurRadius: 26,
                            offset: const Offset(0, 12),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'TODAY',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.2,
                                    color: Colors.white.withAlpha(200),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                TweenAnimationBuilder<double>(
                                  tween: Tween<double>(begin: 0, end: today.toDouble()),
                                  duration: const Duration(milliseconds: 900),
                                  curve: Curves.easeOutCubic,
                                  builder: (context, v, _) => Text(
                                    v.round() <= 0 ? '0m' : fmtListen(v.round()),
                                    style: const TextStyle(
                                      fontSize: 44,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: -1.5,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                Text(
                                  'listened today',
                                  style: TextStyle(
                                    fontSize: 14.5,
                                    color: Colors.white.withAlpha(215),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                            decoration: BoxDecoration(
                              color: Colors.white.withAlpha(40),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Column(
                              children: [
                                const Icon(Icons.local_fire_department_rounded,
                                    color: Colors.white, size: 28),
                                const SizedBox(height: 2),
                                Text(
                                  '${stats.streak}',
                                  style: const TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.white,
                                  ),
                                ),
                                Text(
                                  'day streak',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    color: Colors.white.withAlpha(215),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // --- summary cards
                FadeSlideIn(
                  delay: const Duration(milliseconds: 90),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: _SummaryCard(
                            title: 'THIS WEEK',
                            icon: Icons.calendar_view_week_rounded,
                            big: fmtListen(stats.last7Ms),
                            lines: <String, String>{
                              'Daily average': fmtListen(stats.weekDailyAvgMs.round()),
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _SummaryCard(
                            title: 'THIS YEAR',
                            icon: Icons.calendar_month_rounded,
                            big: fmtListen(stats.yearMs),
                            lines: <String, String>{
                              'Weekly average': fmtListen(stats.yearWeeklyAvgMs.round()),
                              'Daily average': fmtListen(stats.yearDailyAvgMs.round()),
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // --- last 7 days
                FadeSlideIn(
                  delay: const Duration(milliseconds: 160),
                  child: _ChartCard(
                    title: 'Last 7 Days',
                    child: _BarChart(
                      values: week,
                      labels: [for (final d in days) _dayNames[d.weekday - 1]],
                      highlight: 6,
                      height: 130,
                    ),
                  ),
                ),
                // --- months
                FadeSlideIn(
                  delay: const Duration(milliseconds: 230),
                  child: _ChartCard(
                    title: '${DateTime.now().year} by Month',
                    child: _BarChart(
                      values: months,
                      labels: _monthLetters,
                      highlight: nowMonth,
                      height: 110,
                    ),
                  ),
                ),
                // --- most played
                FadeSlideIn(
                  delay: const Duration(milliseconds: 300),
                  child: _ChartCard(
                    title: 'Most Played',
                    child: top.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.symmetric(vertical: 18),
                            child: Text(
                              'Play some music and your favourites will show up here.',
                              style: TextStyle(fontSize: 14.5, color: p.subtext),
                            ),
                          )
                        : Column(
                            children: [
                              for (var i = 0; i < top.length; i++)
                                _TopRow(rank: i + 1, stat: top[i]),
                            ],
                          ),
                  ),
                ),
                // --- all time + reset
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
                  child: Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: p.surface,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      children: [
                        const GradientIcon(Icons.headphones_rounded, size: 32),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('All-time listening',
                                  style: TextStyle(fontSize: 13.5, color: p.subtext)),
                              const SizedBox(height: 2),
                              Text(
                                fmtListen(stats.allTimeMs),
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Tappable(
                          onTap: () async {
                            final ok = await showConfirm(
                              context,
                              title: 'Reset Statistics?',
                              message: 'All listening history will be erased. This cannot be undone.',
                              confirmLabel: 'Reset',
                              destructive: true,
                            );
                            if (ok) {
                              await stats.reset();
                              showToast('Statistics reset');
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                            decoration: BoxDecoration(
                              color: p.surface2,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: const Text(
                              'Reset',
                              style: TextStyle(
                                fontSize: 14.5,
                                fontWeight: FontWeight.w700,
                                color: AppColors.danger,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final String big;
  final Map<String, String> lines;

  const _SummaryCard({
    required this.title,
    required this.icon,
    required this.big,
    required this.lines,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GradientIcon(icon, size: 19),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.9,
                    color: p.subtext,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          GradientText(
            big,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.8,
            ),
          ),
          const SizedBox(height: 10),
          for (final e in lines.entries)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(e.key, style: TextStyle(fontSize: 12.5, color: p.subtext)),
                  ),
                  Text(
                    e.value,
                    style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _ChartCard extends StatelessWidget {
  final String title;
  final Widget child;
  const _ChartCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _BarChart extends StatelessWidget {
  final List<int> values;
  final List<String> labels;
  final int highlight;
  final double height;

  const _BarChart({
    required this.values,
    required this.labels,
    required this.highlight,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    var maxV = 1;
    for (final v in values) {
      if (v > maxV) maxV = v;
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (var i = 0; i < values.length; i++)
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  height: 16,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      fmtShort(values[i]),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: i == highlight ? AppColors.accent : p.subtext,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                SizedBox(
                  height: height,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: TweenAnimationBuilder<double>(
                      tween: Tween<double>(begin: 0, end: values[i] / maxV),
                      duration: Duration(milliseconds: 650 + i * 45),
                      curve: Curves.easeOutCubic,
                      builder: (context, v, _) {
                        final h = math.max(5.0, v * height);
                        return Container(
                          height: h,
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          decoration: BoxDecoration(
                            gradient: values[i] > 0
                                ? (i == highlight ? AppColors.primary : null)
                                : null,
                            color: values[i] > 0
                                ? (i == highlight ? null : alpha(AppColors.blue1, 0.42))
                                : p.surface2,
                            borderRadius: BorderRadius.circular(9),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  labels[i],
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: i == highlight ? FontWeight.w800 : FontWeight.w600,
                    color: i == highlight ? p.text : p.subtext,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class _TopRow extends StatelessWidget {
  final int rank;
  final SongStat stat;
  const _TopRow({required this.rank, required this.stat});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              gradient: rank == 1 ? AppColors.primary : null,
              color: rank == 1 ? null : p.surface2,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(
                '$rank',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                  color: rank == 1 ? Colors.white : p.subtext,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  stat.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                Text(
                  stat.artist,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12.5, color: p.subtext),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                fmtListen(stat.ms),
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
              ),
              Text(
                plural(stat.plays, 'play'),
                style: TextStyle(fontSize: 12, color: p.subtext),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
