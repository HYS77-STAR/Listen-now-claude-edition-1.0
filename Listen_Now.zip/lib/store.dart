import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// Persistent app state: theme, hidden folders, sorting, playlists.
class AppStore extends ChangeNotifier {
  SharedPreferences? _p;

  bool isDark = true;
  final Set<String> hiddenFolders = <String>{};
  final Map<String, SortMode> _sortModes = <String, SortMode>{};
  final Map<String, List<String>> _manual = <String, List<String>>{};
  final List<Playlist> playlists = <Playlist>[];

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    isDark = p.getBool('dark') ?? true;

    hiddenFolders
      ..clear()
      ..addAll(p.getStringList('hidden') ?? const <String>[]);

    try {
      final sm = p.getString('sort_modes');
      if (sm != null) {
        final m = jsonDecode(sm) as Map<String, dynamic>;
        m.forEach((k, v) {
          final i = v is int ? v : 0;
          _sortModes[k] =
              SortMode.values[(i >= 0 && i < SortMode.values.length) ? i : 0];
        });
      }
    } catch (_) {}

    try {
      final mo = p.getString('manual_orders');
      if (mo != null) {
        final m = jsonDecode(mo) as Map<String, dynamic>;
        m.forEach((k, v) {
          _manual[k] = (v as List).map((e) => e.toString()).toList();
        });
      }
    } catch (_) {}

    try {
      final pl = p.getString('playlists');
      if (pl != null) {
        playlists
          ..clear()
          ..addAll((jsonDecode(pl) as List)
              .map((e) => Playlist.fromJson(e as Map<String, dynamic>)));
      }
    } catch (_) {}
  }

  // ------------------------------------------------------------------ theme

  void setDark(bool v) {
    if (isDark == v) return;
    isDark = v;
    _p?.setBool('dark', v);
    notifyListeners();
  }

  // ----------------------------------------------------------- hidden files

  bool isHidden(String folderPath) => hiddenFolders.contains(folderPath);

  void hideFolder(String path) {
    hiddenFolders.add(path);
    _saveHidden();
    notifyListeners();
  }

  void restoreFolder(String path) {
    hiddenFolders.remove(path);
    _saveHidden();
    notifyListeners();
  }

  void restoreAll() {
    hiddenFolders.clear();
    _saveHidden();
    notifyListeners();
  }

  void _saveHidden() => _p?.setStringList('hidden', hiddenFolders.toList());

  // ---------------------------------------------------------------- sorting

  SortMode sortModeOf(String scope, {SortMode def = SortMode.dateAdded}) =>
      _sortModes[scope] ?? def;

  void setSortMode(String scope, SortMode m) {
    _sortModes[scope] = m;
    _saveSort();
    notifyListeners();
  }

  List<String> manualOrder(String scope) => _manual[scope] ?? const <String>[];

  /// Picks a sort mode from the menu. When "Custom" is chosen for the first
  /// time the order currently on screen becomes the starting custom order.
  void chooseSort(String scope, SortMode m, List<String> currentKeys) {
    if (m == SortMode.manual && (_manual[scope] == null || _manual[scope]!.isEmpty)) {
      _manual[scope] = List<String>.of(currentKeys);
    }
    _sortModes[scope] = m;
    _saveSort();
    notifyListeners();
  }

  /// Stores a custom order for [scope] and switches that list to "Custom".
  void setManualOrder(String scope, List<String> keys) {
    _manual[scope] = List<String>.of(keys);
    _sortModes[scope] = SortMode.manual;
    _saveSort();
    notifyListeners();
  }

  void _saveSort() {
    _p?.setString(
        'sort_modes', jsonEncode(_sortModes.map((k, v) => MapEntry(k, v.index))));
    _p?.setString('manual_orders', jsonEncode(_manual));
  }

  /// Returns [items] ordered according to the sort mode saved for [scope].
  List<T> sorted<T>({
    required String scope,
    required List<T> items,
    required String Function(T) keyOf,
    required String Function(T) titleOf,
    required int Function(T) dateOf,
    SortMode def = SortMode.dateAdded,
    List<String>? manualOverride,
  }) {
    final mode = sortModeOf(scope, def: def);

    int byDate(T a, T b) {
      final c = dateOf(b).compareTo(dateOf(a));
      if (c != 0) return c;
      return keyOf(a).compareTo(keyOf(b));
    }

    int byTitle(T a, T b) {
      final c = titleOf(a).toLowerCase().compareTo(titleOf(b).toLowerCase());
      if (c != 0) return c;
      return keyOf(a).compareTo(keyOf(b));
    }

    final list = List<T>.of(items);
    switch (mode) {
      case SortMode.alphabetical:
        list.sort(byTitle);
        return list;
      case SortMode.dateAdded:
        list.sort(byDate);
        return list;
      case SortMode.manual:
        final order = manualOverride ?? manualOrder(scope);
        final index = <String, int>{};
        for (var i = 0; i < order.length; i++) {
          index[order[i]] = i;
        }
        final known = <T>[];
        final unknown = <T>[];
        for (final e in list) {
          if (index.containsKey(keyOf(e))) {
            known.add(e);
          } else {
            unknown.add(e);
          }
        }
        known.sort((a, b) => index[keyOf(a)]!.compareTo(index[keyOf(b)]!));
        unknown.sort(byDate);
        return <T>[...known, ...unknown];
    }
  }

  // -------------------------------------------------------------- playlists

  Playlist? playlistById(String id) {
    for (final p in playlists) {
      if (p.id == id) return p;
    }
    return null;
  }

  Playlist createPlaylist(String name, {Iterable<int> songIds = const <int>[]}) {
    final trimmed = name.trim();
    final now = DateTime.now();
    final pl = Playlist(
      id: now.microsecondsSinceEpoch.toString(),
      name: trimmed.isEmpty ? 'New Playlist' : trimmed,
      songIds: songIds.toSet().toList(),
      createdAt: now.millisecondsSinceEpoch,
    );
    playlists.add(pl);
    _savePlaylists();
    notifyListeners();
    return pl;
  }

  void renamePlaylist(String id, String name) {
    final pl = playlistById(id);
    final trimmed = name.trim();
    if (pl == null || trimmed.isEmpty) return;
    pl.name = trimmed;
    _savePlaylists();
    notifyListeners();
  }

  void deletePlaylist(String id) {
    playlists.removeWhere((p) => p.id == id);
    _manual.remove('playlist:$id');
    _sortModes.remove('playlist:$id');
    final order = _manual['playlists'];
    order?.remove(id);
    _savePlaylists();
    _saveSort();
    notifyListeners();
  }

  /// Adds songs that are not already in the playlist. Returns how many were added.
  int addToPlaylist(String id, Iterable<int> ids) {
    final pl = playlistById(id);
    if (pl == null) return 0;
    final existing = pl.songIds.toSet();
    var added = 0;
    for (final s in ids) {
      if (existing.add(s)) {
        pl.songIds.add(s);
        added++;
      }
    }
    if (added > 0) {
      _savePlaylists();
      notifyListeners();
    }
    return added;
  }

  void removeFromPlaylist(String id, int songId) {
    final pl = playlistById(id);
    if (pl == null) return;
    pl.songIds.remove(songId);
    _savePlaylists();
    notifyListeners();
  }

  /// [visibleOrder] is the new order of the songs currently shown. Songs that
  /// are hidden (folder hidden) keep their place at the end.
  void reorderPlaylistSongs(String id, List<int> visibleOrder) {
    final pl = playlistById(id);
    if (pl == null) return;
    final shown = visibleOrder.toSet();
    final hidden = pl.songIds.where((s) => !shown.contains(s)).toList();
    pl.songIds = <int>[...visibleOrder, ...hidden];
    _sortModes['playlist:$id'] = SortMode.manual;
    _savePlaylists();
    _saveSort();
    notifyListeners();
  }

  void _savePlaylists() {
    _p?.setString('playlists', jsonEncode(playlists.map((p) => p.toJson()).toList()));
  }
}
